#ifndef INTER_CITY_H
#define INTER_CITY_H

#include "Expres.h"

class InterCity : public Expres {
public:
    InterCity(int cislo, Trasa* trasa);
};

#endif
